Live RIPE:
Author: Vladimir Kushnir <vkushnir@gmail.com>

The plugin getting information from RIPE database about selected network and allow to clone it into network description.
Note that the racktables instance must be able to http://apps.db.ripe.net for this plugin to be useful.

Installation:
- Copy the ripe.php, ripe_html.xsl, ripe_text.xsl files into the plugins/ folder of racktables.

In use:
After installation, log into racktables and access a IPv4 network instance and
click on the "Live RIPE" tab. Here you will be presented with RIPE information about this network if it exists in ripe database.

Known issues: