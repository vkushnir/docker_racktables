rtapi
=====

Racktables API

Python module for accessing and manipulating racktables objects.

For more information and source visit https://github.com/rvojcik/rtapi

