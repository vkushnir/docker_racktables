Racktables CableID Plugin v0.2
---------------------------------------------------------------
2014-08-20 - Mogilowski Sebastian <sebastian@mogilowski.net>
---------------------------------------------------------------
Website: http://www.mogilowski.net/projects/racktables
---------------------------------------------------------------

INSTALL:

Copy cableIDHelper.php into the plugin directory
