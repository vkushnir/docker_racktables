racktables-stuff
================

A small plugin for Racktables.org, only tested by me.

Tested versions 0.20.7, 0.20.8

# Installation

* Copy the contents of the plugins/ directory to the RackTables plugins/ directory.
* you can apply a patch to wwwroot/inc/interface.php to rotate labels in vertical boxes (Blades and stuff)
* open a rack row in the racktables web frontend, there should be a tab "Full Row View", enjoy.

Feedback is welcome!

# Preview

![Preview hosted on github](https://raw.githubusercontent.com/RackTables/racktables-contribs/master/full_row_view/full_row_view.png)
